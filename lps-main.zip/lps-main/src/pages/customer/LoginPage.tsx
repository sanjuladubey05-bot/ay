import { useState, type FormEvent } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { ROUTES } from '../../configuration/routes';
import { useAuth } from '../../hooks/useAuth';
import { apiClient } from '../../services/apiClient';

export function LoginPage() {
  const { setUser, refreshAuth } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const locationState = (location.state as { from?: string; orderDraft?: unknown } | null) || null;
  const redirectTo = locationState?.from || ROUTES.ORDERS;

  const [mode, setMode] = useState<'login' | 'reset'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [infoMsg, setInfoMsg] = useState<string | null>(null);

  async function handleLogin(e: FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setErrorMsg(null);
    setInfoMsg(null);
    try {
      const res = await apiClient.customerLogin({ email, password });
      setUser(res.user);
      await refreshAuth();
      navigate(redirectTo, {
        replace: true,
        state: locationState?.orderDraft ? { orderDraft: locationState.orderDraft } : undefined,
      });
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to sign in.');
    } finally {
      setSubmitting(false);
    }
  }

  async function handleResetRequest(e: FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setErrorMsg(null);
    setInfoMsg(null);
    try {
      const res = await apiClient.requestPasswordReset(email);
      setInfoMsg(res.message);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Could not process password reset.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="mx-auto max-w-[460px] px-6 py-16">
      <div className="bg-[#111118] border border-white/[0.08] rounded-xl p-8 space-y-6">
        <div className="space-y-1.5">
          <h1 className="text-2xl font-bold text-white">
            {mode === 'login' ? 'Customer Sign In' : 'Reset Customer Password'}
          </h1>
          <p className="text-sm text-zinc-400">
            {mode === 'login'
              ? 'Access your LPS STORE account and track your top-up orders.'
              : 'Request a single-use password reset token.'}
          </p>
        </div>

        {errorMsg && (
          <div
            role="alert"
            className="bg-red-500/10 border border-red-500/30 rounded-lg p-3.5 text-sm text-red-200"
          >
            {errorMsg}
          </div>
        )}

        {infoMsg && (
          <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-3.5 text-sm text-blue-200">
            {infoMsg}
          </div>
        )}

        {mode === 'login' ? (
          <form onSubmit={(e) => void handleLogin(e)} className="space-y-4">
            <div className="space-y-1.5">
              <label htmlFor="customer-email" className="block text-xs font-medium text-zinc-300">
                Email Address
              </label>
              <input
                id="customer-email"
                type="email"
                required
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full rounded-lg bg-[#09090E] border border-white/[0.14] px-3.5 py-2.5 text-sm text-white placeholder:text-zinc-600 focus:border-blue-500"
              />
            </div>

            <div className="space-y-1.5">
              <label htmlFor="customer-password" className="block text-xs font-medium text-zinc-300">
                Password
              </label>
              <input
                id="customer-password"
                type="password"
                required
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-lg bg-[#09090E] border border-white/[0.14] px-3.5 py-2.5 text-sm text-white placeholder:text-zinc-600 focus:border-blue-500"
              />
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full py-2.5 rounded-lg bg-violet-600 text-sm font-semibold text-white hover:bg-violet-500 transition-colors disabled:opacity-50"
            >
              {submitting ? 'Signing In...' : 'Sign In'}
            </button>
          </form>
        ) : (
          <form onSubmit={(e) => void handleResetRequest(e)} className="space-y-4">
            <div className="space-y-1.5">
              <label htmlFor="reset-email" className="block text-xs font-medium text-zinc-300">
                Account Email
              </label>
              <input
                id="reset-email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full rounded-lg bg-[#09090E] border border-white/[0.14] px-3.5 py-2.5 text-sm text-white placeholder:text-zinc-600 focus:border-blue-500"
              />
            </div>
            <button
              type="submit"
              disabled={submitting}
              className="w-full py-2.5 rounded-lg bg-blue-600 text-sm font-semibold text-white hover:bg-blue-500 transition-colors disabled:opacity-50"
            >
              {submitting ? 'Submitting...' : 'Request Password Reset'}
            </button>
          </form>
        )}

        <div className="pt-4 border-t border-white/[0.08] flex items-center justify-between text-xs text-zinc-400">
          <button
            type="button"
            onClick={() => {
              setMode(mode === 'login' ? 'reset' : 'login');
              setErrorMsg(null);
              setInfoMsg(null);
            }}
            className="hover:text-white transition-colors"
          >
            {mode === 'login' ? 'Forgot password?' : 'Back to Sign In'}
          </button>
          <Link
            to={ROUTES.REGISTER}
            state={locationState || undefined}
            className="text-violet-400 hover:text-violet-300"
          >
            Create an account
          </Link>
        </div>
      </div>
    </div>
  );
}
